<script>
var TRAFFICCONF_SWITCH_WARNING_TURNOFF_TRUNK="포트 미러링에 사용할 포트를 포트 트렁킹에서 사용하고 있습니다";var TRAFFICCONF_SWITCH_WARNING_TURNOFF_PORTMIRROR="포트 트렁킹에 사용할 포트를 포트 미러링에서 사용하고 있습니다";
</script>
