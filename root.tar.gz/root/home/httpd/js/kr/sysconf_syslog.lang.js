<script>
var SYSCONF_SYSLOG_WANRING="시간 범위가 잘못되었습니다.";var SYSCONF_SYSLOG_EMAIL_CONFIRM="E-mail 리포트를 보내시겠습니까?";var SYSCONF_SYSLOG_CLEAR_CONFIRM="모든 시스템 로그가 지워집니다";
</script>
