<script>
var MSG_CONNECTION_MAX_WARNING="최대 컨넥션 수가 초기값 보다 크거나 제한이 없을 경우,\n일부 환경에서는 시스템의 메모리 부족으로 인해 오작동의 원인이 될 수 있습니다.\n\n그래도 계속하시겠습니까?";var MSG_CONNECTION_MAX_TOO_SMALL="최대 컨넥션 수가 너무 작습니다. 512 이상으로 설정하십시오.";var MSG_UDP_CONNECTION_MAX_TOO_BIG="최대 UDP 컨넥션 수는 10에서 최대 컨넥션 수사이의 값으로 설정되어야 합니다.";var MSG_ICMP_CONNECTION_MAX_TOO_BIG="최대 ICMP 컨넥션 수는 최대 컨넥션 수 보다 작게 설정되어야 합니다.";var MSG_INVALID_RATE_PER_MAX="올바른 PC별 최대 컨넥션 비율의 값을 입력하십시오.";var TRAFFICCONF_CONNCTRL_INVALID_TIME="시간이 잘못되었습니다.";
</script>
