<script>
var SYSCONF_ONLINE_UPGRADE_CONFIRM="업그레이드 수행 중에는 공유기의 모든 기능을 사용할 수 없습니다.\n계속하시겠습니까?";var FIRMUP_DONE_TXT="펌웨어 업그레이드가 완료되었습니다.\n확인 버튼을 누르면 로그인 페이지로 재접속합니다.";
</script>
