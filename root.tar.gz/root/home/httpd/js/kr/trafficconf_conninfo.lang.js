<script>
var TRAFFICCONF_CONNINFO_DELETE_CONN="지정된 IP주소의 커넥션을 삭제하시겠습니까?";
</script>
