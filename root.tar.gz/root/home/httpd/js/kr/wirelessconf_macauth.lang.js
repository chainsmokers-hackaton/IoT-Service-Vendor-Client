<script>
var MACAUTH_DISCONNECT_CONFIRM_TXT="현재 무선으로 설정 페이지에 접속되어 있습니다.\n설정 변경 시, 무선 연결이 끊어질 수 있습니다.\n계속 진행하시겠습니까?";var MACAUTH_AUTH_TXT="무선인증";
</script>
