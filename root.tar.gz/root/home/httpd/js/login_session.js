<script>
function login_session(){document.form.submit()}
</script>
