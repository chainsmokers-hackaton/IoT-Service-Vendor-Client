<script>
var SYSCONF_ONLINE_UPGRADE_CONFIRM="All router's functions will be stopped during firmware upgrade.\nContinue?";var FIRMUP_DONE_TXT="Firmware upgrade is done.\nClick 'OK' button to continue.";
</script>
