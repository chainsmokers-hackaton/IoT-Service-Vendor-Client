<script>
var EXPERTCONF_GAMINGVPN_APPLYSTR="Applying";
</script>
