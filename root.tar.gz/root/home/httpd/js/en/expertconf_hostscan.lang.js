<script>
var ICMP_PING=0;var ARP_PING=1;var PING_SCAN=0;var TCP_PORT_SCAN=1;var SYSINFO_HOST_INVALID_TIMEOUT="Time out is blank.";var SYSINFO_HOST_TIMERANGE="Time out should be more than 1 sec.";var SYSINFO_HOST_INVALID_DATASIZE="Data Size is blank.";var SYSINFO_HOST_DATARANGE="Data range should be from 0 to 65,000.";var SYSINFO_HOST_INVALID_START="Start Port is blank";var SYSINFO_HOST_PORTRANGE="Port range should be form 0 to 65,535.";var SYSINFO_HOST_DELETING="Deleting..";var SYSINFO_HOST_STARTING="Starting..";var SYSINFO_HOST_STOPPING="Stopping..";
</script>
