<script>
var BLANK_PW_TXT="Not configured";
</script>
