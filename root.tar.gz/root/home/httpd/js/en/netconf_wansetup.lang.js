<script>
var NETCONF_WANSETUP_APPLYSTR="Applying...";var NETCONF_WANSETUP_CONNSTR="Connecting...";var NETCONF_WANSETUP_DISCONNSTR="Disconnecting...";var NETCONF_INTERNET_DHCP_MTU_INVALID="MTU is not over 1500.";var NETCONF_INTERNET_PPP_MTU_INVALID="MTU is net over 1492.";var NETCONF_INTERNET_KEEP_ALIVE_MSG="Invalid max idle tme.";var NETCONF_INTERNET_GW_INVALID_NETWORK="Default Gateway is the same as internal network.";var NETCONF_WANSETUP_CONFIRM_WANINFO="Do you want to confirm WAN connection info?";
</script>
