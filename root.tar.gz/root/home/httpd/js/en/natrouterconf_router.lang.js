<script>
var MSG_NO_DEL_ROUTING_TABLE="Select routing table to delete!";var NETCONF_ROUTE_ENTRY_DELETE="Do you want to delete routing table?";var NETCONF_ROUTE_ENTRY_SELECT="Select routing table to be deleted.";var MSG_MAX_IP_RULES="Max number of IP is 20";
</script>
