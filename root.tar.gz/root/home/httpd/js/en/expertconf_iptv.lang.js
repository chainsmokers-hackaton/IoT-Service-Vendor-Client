<script>
var MSG_IGMP_REBOOT="Reboot to change IPTV(MOD) configuration?";
</script>
