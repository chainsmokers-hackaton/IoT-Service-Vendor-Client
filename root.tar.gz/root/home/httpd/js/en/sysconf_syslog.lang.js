<script>
var SYSCONF_SYSLOG_WANRING="Invalid Hour.";var SYSCONF_SYSLOG_EMAIL_CONFIRM="Send system log report to the admin by e-mail now.";var SYSCONF_SYSLOG_CLEAR_CONFIRM="All system log will be cleared.";
</script>
