<script>
function ClearLinkStat(){var F=document.linkstat_fm;F.act.value="clear";F.submit()}
</script>
